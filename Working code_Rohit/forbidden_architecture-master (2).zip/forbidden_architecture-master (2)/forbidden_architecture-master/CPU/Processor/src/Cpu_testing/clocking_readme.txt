The following files were generated for 'clocking' in directory 
I:\GitHub\forbidden_architecture\CPU\Processor\src\Cpu_testing\

clocking_readme.txt:
   Text file indicating the files generated and how they are used.

clocking_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.

clocking_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

