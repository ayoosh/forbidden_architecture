The following files were generated for 'MDU_Divider' in directory
E:\CPU\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * MDU_Divider.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * MDU_Divider.ngc
   * MDU_Divider.v
   * MDU_Divider.veo

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * MDU_Divider.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * MDU_Divider.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * MDU_Divider.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * MDU_Divider_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * MDU_Divider.gise
   * MDU_Divider.xise
   * _xmsgs/pn_parser.xmsgs

Deliver Readme:
   Readme file for the IP.

   * MDU_Divider_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * MDU_Divider_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

