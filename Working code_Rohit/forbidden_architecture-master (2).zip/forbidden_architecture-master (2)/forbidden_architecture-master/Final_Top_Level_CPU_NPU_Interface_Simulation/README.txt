1. Add Chipscope modules .xco file only if you plan to use CHIPSCOPE
2. Add all verilog files in DVI folder except xfifo_1.v .... Instead Add - xfifo_1.xco
3. Add all verilog files in SPART folder
4. Add all files in top level folder. Add only one top_module.v accordingly. 
5. Add UCF
6. Add user_design/RTL - all verilog files

All set to go!