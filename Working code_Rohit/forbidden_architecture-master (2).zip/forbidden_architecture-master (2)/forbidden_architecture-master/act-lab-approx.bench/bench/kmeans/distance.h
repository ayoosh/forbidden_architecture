/*
 * distance.h
 *
 *  Created on: May 7, 2012
 *      Author: hadianeh
 */

#ifndef DISTANCE_H_
#define DISTANCE_H_

#include "rgbimage.h"
#include "segmentation.h"

void assignCluster(RgbPixel* p, Clusters* clusters);

#endif /* DISTANCE_H_ */
