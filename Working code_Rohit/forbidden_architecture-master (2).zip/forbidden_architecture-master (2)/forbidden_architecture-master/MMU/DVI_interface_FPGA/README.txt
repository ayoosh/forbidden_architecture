1. Add all files present here
2. Add ROM xco file from ../EMMA_ROM
3. Add ILA & ICON too .. if chipscopre requred, currently commented